module.exports = {
    token: "ODcxMTg5NzA4MDYxOTQ5OTcy.YQXspA.7MLGkimfW5uisHvZEphHaMPD7n8",
    prefix: "!",
    admins: [
        "862289491041320984"
],
    debug: true,
    countChannel: "countChannelID"
};